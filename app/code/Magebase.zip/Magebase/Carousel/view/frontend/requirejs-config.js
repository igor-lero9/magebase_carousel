var config = {
    paths: {
        'magebase/carousel': 'Magebase_Carousel/js/owl.carousel.min'
    },
    shim: {
        'magebase/carousel':{
            deps: ['jquery']
        }
    }

}